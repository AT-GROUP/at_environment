
#include "AKBDocument.h"

AKBDocument::AKBDocument()
{
}


AKBDocument::~AKBDocument()
{
}

void AKBDocument::serialize(_xmlNode * document_node) const
{
}

AError AKBDocument::deserialize(_xmlNode * document_node)
{
	return AError();
}