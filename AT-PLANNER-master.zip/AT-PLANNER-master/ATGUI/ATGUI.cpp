#include "ATGUI.h"

ATGUI::ATGUI()
{

}

ATGUI::~ATGUI()
{

}
