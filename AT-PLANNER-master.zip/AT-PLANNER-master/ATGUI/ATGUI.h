#ifndef ATGUI_H
#define ATGUI_H

#include "atgui_global.h"

class ATGUI_EXPORT ATGUI
{
public:
	ATGUI();
	~ATGUI();

private:

};

#endif // ATGUI_H
